part of 'advertising_cubit.dart';

@immutable
abstract class AdvertisingState {}

class AdvertisingInitial extends AdvertisingState {}
