part of 'call_sreen_bloc.dart';

@immutable
abstract class CallSreenEvent {}
