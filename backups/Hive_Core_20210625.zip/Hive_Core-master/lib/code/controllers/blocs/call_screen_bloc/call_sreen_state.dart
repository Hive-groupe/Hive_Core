part of 'call_sreen_bloc.dart';

abstract class CallSreenState {
  String currentUserId;
}

class CallSreenInitial extends CallSreenState {}
