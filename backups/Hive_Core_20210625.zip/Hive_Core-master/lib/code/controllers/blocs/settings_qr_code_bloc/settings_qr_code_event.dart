part of 'settings_qr_code_bloc.dart';

@immutable
abstract class SettingsQrCodeEvent {}
