part of 'settings_qr_code_bloc.dart';

@immutable
abstract class SettingsQrCodeState {}

class SettingsQrCodeInitial extends SettingsQrCodeState {}
