part of 'assistant_bloc.dart';

@immutable
abstract class AssistantEvent {}
