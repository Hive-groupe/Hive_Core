part of 'assistant_bloc.dart';

@immutable
abstract class AssistantState {}

class AssistantInitial extends AssistantState {}
