part of 'advertising_bloc.dart';

abstract class AdvertisingState extends Equatable {
  const AdvertisingState();
}

class AdvertisingInitial extends AdvertisingState {
  @override
  List<Object> get props => [];
}
