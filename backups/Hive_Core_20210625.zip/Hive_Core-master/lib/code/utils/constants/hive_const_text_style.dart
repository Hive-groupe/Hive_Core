import 'package:flutter/material.dart';

class HiveCoreConstTextStyle {
  static const TextStyle form_title = TextStyle(fontSize: 18);
  static const TextStyle filter_title = TextStyle(fontSize: 25);
  static const TextStyle list_title = TextStyle(fontSize: 25);
}
